 $(document).ready(function(){
 	$('.offers').slick({
	  infinite: true,
	  slidesToShow: 4,
	  slidesToScroll: 1
	});
	$('.portfolio-list').slick({
	  infinite: true,
	  slidesToShow: 4,
	  slidesToScroll: 1
	});
});